import { useEffect, useState } from 'react'
import { getAllPlans, addCommentToPlan } from '../services/api'

const PublicPlansPage = () => {
  const [plans, setPlans] = useState([])

  useEffect(() => {
    getAllPlans().then(res => setPlans(res.data))
  }, [])

  const handleComment = (planId, comment) => {
    const author_id = localStorage.getItem('student_id') // Ajustar si usas otro sistema
    addCommentToPlan(planId, { author_id, content: comment }).then(() => alert('Comentario enviado'))
  }

  return (
    <div>
      <h2>Planes Públicos</h2>
      {plans.map(plan => (
        <div key={plan.subject_code + plan.student_id + plan.semester} className="border p-2 my-2">
          <h3>{plan.subject_code} - {plan.semester}</h3>
          <p>Actividades: {plan.activities.length}</p>
          <textarea placeholder="Escribe un comentario..." onBlur={(e) => handleComment(plan.id, e.target.value)} />
        </div>
      ))}
    </div>
  )
}

export default PublicPlansPage
