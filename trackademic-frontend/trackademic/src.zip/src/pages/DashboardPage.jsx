import { useEffect, useState } from "react";
import { getPlansByStudent, getEstimatedGrades } from "../services/api";
import { useAuth } from "../context/AuthContext";
import { Link } from "react-router-dom";
import Sidebar from "../components/Sidebar";
import { Navigate } from "react-router-dom";

const DashboardPage = () => {
  const { user } = useAuth();
  const [plans, setPlans] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchPlansWithAverages = async () => {
      try {
        const res = await getPlansByStudent(user.id);

        // Calcula promedio estimado por cada plan
        const plansWithAverages = await Promise.all(
          res.data.map(async (plan) => {
            try {
              const estimateRes = await getEstimatedGrades(
                plan.student_id,
                plan.subject_code,
                plan.semester
              );
              return { ...plan, average: estimateRes.data };
            } catch (error) {
              console.error("Error al calcular promedio:", error);
              return { ...plan, average: null };
            }
          })
        );

        setPlans(plansWithAverages);
      } catch (err) {
        console.error("Error al obtener planes:", err);
      } finally {
        setLoading(false);
      }
    };

    if (user?.id) {
      fetchPlansWithAverages();
    }
  }, [user]);

  return (
    <>
      <div className="flex">
        <Sidebar />
        <main className="flex-1 p-4">
          <div>
            <h1 className="text-3xl font-bold text-white mb-6">
              Mis Planes de Evaluación
            </h1>

            {loading ? (
              <div className="text-white">Cargando...</div>
            ) : plans.length === 0 ? (
              <div className="text-white">
                No tienes planes registrados.{" "}
                <Link to="/plans/new" className="link link-primary">
                  Crear uno
                </Link>
              </div>
            ) : (
              <div className="grid gap-6 sm:grid-cols-1 md:grid-cols-2 xl:grid-cols-3">
                {plans.map((plan, index) => {
                  const totalPercentage =
                    plan.activities?.reduce(
                      (acc, act) => acc + act.percentage,
                      0
                    ) ?? 0;
                  const isComplete = totalPercentage === 100;

                  return (
                    <div
                      key={index}
                      className="card bg-base-100 shadow-xl p-4 transition hover:shadow-2xl border border-base-300"
                    >
                      <div className="card-body">
                        <h2 className="text-xl font-bold">
                          {plan.subject_code}
                        </h2>
                        <p className="text-sm text-gray-400">
                          Semestre: {plan.semester}
                        </p>

                        <div className="mt-2">
                          <p className="text-lg">
                            Promedio:{" "}
                            <span
                              className={`font-bold ${
                                plan.average < 3
                                  ? "text-error"
                                  : plan.average < 4
                                  ? "text-warning"
                                  : "text-success"
                              }`}
                            >
                              {plan.average !== null
                                ? plan.average.toFixed(2)
                                : "No calculado"}
                            </span>
                          </p>
                          <p
                            className={`text-sm ${
                              isComplete ? "text-success" : "text-warning"
                            }`}
                          >
                            {isComplete
                              ? "Plan completo (100%)"
                              : `Plan incompleto (${totalPercentage}%)`}
                          </p>
                        </div>

                        <div className="mt-4 flex flex-col gap-2">
                          <Link
                            to={`/dashboard/plan/${plan.semester}/${plan.subject_code}`}
                            className="btn btn-outline btn-sm"
                          >
                            Ver Detalles
                          </Link>
                          <Link
                            to={`/dashboard/estimador?semester=${plan.semester}&subject_code=${plan.subject_code}`}
                            className="btn bg-cyan-400 btn-sm text-base-100"
                          >
                            Estimar Nota
                          </Link>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </main>
      </div>
    </>
  );
};

export default DashboardPage;
